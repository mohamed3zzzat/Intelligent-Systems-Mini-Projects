import numpy as np


class Field:
    """The farm environment."""

    def __init__(self, seed=0):
        self.rng = np.random.default_rng(seed)
        self.moisture = 0.55

    def weather(self):
        heat = self.rng.uniform(0.02, 0.09)
        rain = self.rng.choice([0.0, 0.15], p=[0.85, 0.15])

        # The forecast is correct 80% of the time.
        if self.rng.random() < 0.80:
            forecast_rain = rain > 0
        else:
            forecast_rain = rain == 0

        # Keep weather random numbers separate from sensor noise.
        sensor_seed = int(self.rng.integers(0, 1_000_000_000))
        return {
            "heat": heat,
            "rain": rain,
            "forecast_rain": forecast_rain,
            "sensor_seed": sensor_seed
        }

    def step(self, irrigation, weather):
        self.moisture = min(
            1.0,
            max(0.0, self.moisture - weather["heat"]
                + weather["rain"] + irrigation)
        )
        return self.moisture


class SmartIrrigator:
    """A simple agent that senses, decides and learns."""

    def __init__(self):
        self.target = 0.50
        self.estimate = 0.55

    def perceive(self, moisture, weather):
        # A noisy sensor reading.
        rng = np.random.default_rng(weather["sensor_seed"])
        reading = moisture + rng.normal(0, 0.06)

        # Simple filter: combine prediction and sensor reading.
        predicted = self.estimate - weather["heat"]
        if weather["forecast_rain"]:
            predicted += 0.12

        k = 0.5
        self.estimate = predicted + k * (reading - predicted)
        self.estimate = min(1.0, max(0.0, self.estimate))

        return self.estimate

    def decide(self, moisture, forecast_rain):
        amount = max(0.0, self.target - moisture) * 0.9

        # Use less water when rain is expected.
        if forecast_rain:
            amount *= 0.4

        return min(0.18, amount)

    def learn(self, moisture):
        # Adjust the target using the result.
        if moisture < 0.35:
            self.target = min(0.65, self.target + 0.02)
        elif moisture > 0.65:
            self.target = max(0.45, self.target - 0.005)


def run_smart(weather_days, start_moisture=0.55):
    agent = SmartIrrigator()
    moisture = start_moisture
    water = 0.0
    stress_days = 0
    pump_days = 0
    energy = 0.0

    for weather in weather_days:
        sensed = agent.perceive(moisture, weather)
        irrigation = agent.decide(sensed, weather["forecast_rain"])

        moisture = min(
            1.0,
            max(0.0, moisture - weather["heat"] + weather["rain"] + irrigation)
        )
        agent.learn(moisture)

        water += irrigation
        stress_days += moisture < 0.35
        pump_days += irrigation > 0.001

        # Assumption: pump energy is proportional to water pumped.
        energy += irrigation * 1.0

    return water, stress_days, pump_days, energy


def run_fixed_timer(weather_days, start_moisture=0.55):
    moisture = start_moisture
    water = 0.0
    stress_days = 0
    pump_days = 0
    energy = 0.0

    for day, weather in enumerate(weather_days):
        irrigation = 0.12 if day % 2 == 0 else 0.0

        moisture = min(
            1.0,
            max(0.0, moisture - weather["heat"] + weather["rain"] + irrigation)
        )

        water += irrigation
        stress_days += moisture < 0.35
        pump_days += irrigation > 0.001
        energy += irrigation * 1.0

    return water, stress_days, pump_days, energy


def make_weather(seed, days=90):
    """Create weather once so both controllers get the same conditions."""
    rng = np.random.default_rng(seed)
    weather_days = []

    for _ in range(days):
        heat = rng.uniform(0.02, 0.09)
        rain = rng.choice([0.0, 0.15], p=[0.85, 0.15])

        if rng.random() < 0.80:
            forecast_rain = rain > 0
        else:
            forecast_rain = rain == 0

        sensor_seed = int(rng.integers(0, 1_000_000_000))
        weather_days.append({
            "heat": heat,
            "rain": rain,
            "forecast_rain": forecast_rain,
            "sensor_seed": sensor_seed
        })

    return weather_days


def main():
    smart_results = []
    timer_results = []

    # At least 20 experiments, each lasting 90 days.
    for seed in range(20):
        weather_days = make_weather(seed)
        smart_results.append(run_smart(weather_days))
        timer_results.append(run_fixed_timer(weather_days))

    smart = np.array(smart_results)
    timer = np.array(timer_results)

    print("Average results over 20 runs (90 days each)")
    print("-" * 76)
    print(f"{'Controller':<18}{'Water':>12}{'Stress days':>15}"
          f"{'Pump days':>13}{'Energy':>12}")
    print("-" * 76)

    for name, result in [("Fixed timer", timer), ("Smart system", smart)]:
        avg = result.mean(axis=0)
        print(f"{name:<18}{avg[0]:>12.2f}{avg[1]:>15.2f}"
              f"{avg[2]:>13.2f}{avg[3]:>12.2f}")

    print("\nEnergy assumption: energy = irrigation amount x 1.0 unit.")


if __name__ == "__main__":
    main()
