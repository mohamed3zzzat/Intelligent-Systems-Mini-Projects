import random
from collections import deque

GRID = [
    "..........",
    ".##.##.##.",
    "..........",
    ".##.##.##.",
    ".........."
]

SHELVES = {
    "A": (0, 3),
    "B": (2, 6),
    "C": (4, 9)
}
DOCK = (4, 0)

ROWS = len(GRID)
COLS = len(GRID[0])
FREE_CELLS = [
    (r, c) for r in range(ROWS) for c in range(COLS)
    if GRID[r][c] == "."
]

MOVES = [
    (-1, 0),  # Up
    (1, 0),   # Down
    (0, -1),  # Left
    (0, 1)    # Right
]


class Warehouse:
    """Warehouse with workers that move randomly."""

    def __init__(self, n_workers=3, seed=0):
        self.rng = random.Random(seed)
        possible = [p for p in FREE_CELLS if p not in SHELVES.values()
                    and p != DOCK]
        self.workers = self.rng.sample(possible, n_workers)

    def step_workers(self):
        new_workers = []
        for pos in self.workers:
            options = [pos]
            for dr, dc in MOVES:
                nxt = (pos[0] + dr, pos[1] + dc)
                if (nxt in FREE_CELLS and nxt not in SHELVES.values()
                        and nxt != DOCK and nxt not in new_workers):
                    options.append(nxt)
            new_workers.append(self.rng.choice(options))
        self.workers = new_workers


class HybridAgent:
    """BFS planning with a reactive safety check."""

    def plan(self, start, goal, blocked):
        queue = deque([start])
        parent = {start: None}

        while queue:
            current = queue.popleft()
            if current == goal:
                break

            for dr, dc in MOVES:
                nxt = (current[0] + dr, current[1] + dc)
                if (nxt in FREE_CELLS and nxt not in blocked
                        and nxt not in parent):
                    parent[nxt] = current
                    queue.append(nxt)

        if goal not in parent:
            return []

        path = []
        current = goal
        while current != start:
            path.append(current)
            current = parent[current]
        path.reverse()
        return path

    def safe(self, next_cell, workers):
        return next_cell not in workers


def run_order(order, seed):
    warehouse = Warehouse(seed=seed)
    agent = HybridAgent()
    position = DOCK
    steps = 0
    waits = 0
    replans = 0
    collisions = 0
    blocked_times = 0
    delivered = []

    # Visit the shelves in the order, then return to the dock.
    goals = [SHELVES[name] for name in order] + [DOCK]

    for goal in goals:
        path = agent.plan(position, goal, set(warehouse.workers))
        if not path and position != goal:
            replans += 1
            path = agent.plan(position, goal, set())

        while position != goal:
            if not path:
                path = agent.plan(position, goal, set(warehouse.workers))
                replans += 1
                if not path:
                    # Wait for a worker to move, then plan again.
                    waits += 1
                    steps += 1
                    warehouse.step_workers()
                    blocked_times += 1
                    if blocked_times > 200:
                        return steps, waits, replans, collisions, delivered
                    continue

            next_cell = path[0]

            # Reactive layer: never enter a worker's current cell.
            if not agent.safe(next_cell, warehouse.workers):
                waits += 1
                steps += 1
                blocked_times += 1
                warehouse.step_workers()

                # Re-plan after repeated blocking.
                if blocked_times % 2 == 0:
                    path = agent.plan(position, goal, set(warehouse.workers))
                    replans += 1
                continue

            position = next_cell
            path.pop(0)
            steps += 1
            blocked_times = 0
            if position in warehouse.workers:
                collisions += 1
            warehouse.step_workers()

        if goal != DOCK:
            delivered.append(goal)

    return steps, waits, replans, collisions, delivered


def main():
    orders = []
    for seed in range(10):
        order = ["A", "B", "C"]
        random.Random(seed).shuffle(order)
        orders.append(tuple(order))

    print("Hybrid Warehouse Delivery Agent")
    print("10 random-order simulations")
    print("-" * 76)
    print(f"{'Run':<6}{'Order':<14}{'Steps':>10}{'Waits':>10}"
          f"{'Re-plans':>12}{'Collisions':>14}")
    print("-" * 76)

    results = []
    for i, order in enumerate(orders):
        result = run_order(order, seed=i)
        results.append(result)
        print(f"{i + 1:<6}{'-'.join(order):<14}{result[0]:>10}"
              f"{result[1]:>10}{result[2]:>12}{result[3]:>14}")

    print("-" * 76)
    print("Average steps:", round(sum(x[0] for x in results) / len(results), 2))
    print("Average waits:", round(sum(x[1] for x in results) / len(results), 2))
    print("Average re-plans:", round(sum(x[2] for x in results) / len(results), 2))
    print("Total collisions:", sum(x[3] for x in results))


if __name__ == "__main__":
    main()
